-- =====================================================================
--  MP Inventory Sync — структура БД (MySQL 8.0)
--  Кодировка utf8mb4, движок InnoDB (поддержка внешних ключей).
--  Запуск:  mysql -u root -p < sql/schema.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `mp_sync`
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE `mp_sync`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `sync_runs`;
DROP TABLE IF EXISTS `product_mappings`;
DROP TABLE IF EXISTS `marketplace_connections`;
DROP TABLE IF EXISTS `products`;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
--  products — локальный склад (источник истины по остаткам и ценам)
-- ---------------------------------------------------------------------
CREATE TABLE `products` (
    `id`             INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `sku`            VARCHAR(64)     NOT NULL COMMENT 'Внутренний артикул',
    `name`           VARCHAR(255)    NOT NULL,
    `purchase_price` DECIMAL(12, 2)  NOT NULL DEFAULT 0.00 COMMENT 'Закупочная цена',
    `retail_price`   DECIMAL(12, 2)  NOT NULL DEFAULT 0.00 COMMENT 'Розничная цена (эталон для МП)',
    `current_stock`  INT             NOT NULL DEFAULT 0     COMMENT 'Остаток на локальном складе',
    `created_at`     TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`     TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_products_sku` (`sku`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
--  marketplace_connections — учётные данные API маркетплейсов
-- ---------------------------------------------------------------------
CREATE TABLE `marketplace_connections` (
    `id`               INT UNSIGNED          NOT NULL AUTO_INCREMENT,
    `marketplace_type` ENUM('wb', 'ozon')    NOT NULL,
    `api_key`          VARCHAR(512)          NOT NULL COMMENT 'Зашифрованный (enc:v1:) JWT WB / Api-Key Ozon',
    `client_id`        VARCHAR(128)          NULL     COMMENT 'Зашифрованный Client-Id Ozon; NULL для WB',
    `warehouse_id`     VARCHAR(64)           NULL     COMMENT 'warehouseId WB / warehouse_id Ozon',
    `status`           ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    `created_at`       TIMESTAMP             NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_conn_type_status` (`marketplace_type`, `status`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
--  product_mappings — связка локального товара с карточкой на МП
-- ---------------------------------------------------------------------
CREATE TABLE `product_mappings` (
    `id`                INT UNSIGNED       NOT NULL AUTO_INCREMENT,
    `product_id`        INT UNSIGNED       NOT NULL,
    `marketplace_type`  ENUM('wb', 'ozon') NOT NULL,
    `marketplace_sku`   VARCHAR(128)       NOT NULL COMMENT 'barcode (WB остатки) или offer_id (Ozon)',
    `nm_id`             VARCHAR(64)        NULL     COMMENT 'nmID WB для операций с ценами; NULL для Ozon',
    `sync_status`       ENUM('pending', 'synced', 'mismatch', 'error') NOT NULL DEFAULT 'pending',
    `last_remote_stock` INT                NULL COMMENT 'Последний полученный остаток с МП',
    `last_remote_price` DECIMAL(12, 2)     NULL COMMENT 'Последняя полученная цена с МП',
    `last_sync_at`      TIMESTAMP          NULL,
    `created_at`        TIMESTAMP          NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_mapping` (`marketplace_type`, `marketplace_sku`),
    KEY `idx_map_product` (`product_id`),
    KEY `idx_map_status` (`sync_status`),
    CONSTRAINT `fk_map_product`
        FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
--  sync_runs — журнал прогонов синхронизации (веб-кнопка и cron)
-- ---------------------------------------------------------------------
CREATE TABLE `sync_runs` (
    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `source`     ENUM('web', 'cron') NOT NULL DEFAULT 'web',
    `total`      INT NOT NULL DEFAULT 0,
    `synced`     INT NOT NULL DEFAULT 0,
    `mismatch`   INT NOT NULL DEFAULT 0,
    `error`      INT NOT NULL DEFAULT 0,
    `demo_mode`  TINYINT(1) NOT NULL DEFAULT 0,
    `auto_push`  TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_runs_created` (`created_at`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================================
--  ДЕМО-ДАННЫЕ
--  Подобраны так, чтобы в демо-режиме (mock) дашборд показал смесь
--  статусов: «Синхронизировано», «Расхождение», «Ошибка».
-- =====================================================================

INSERT INTO `products` (`id`, `sku`, `name`, `purchase_price`, `retail_price`, `current_stock`) VALUES
    (1, 'TS-001', 'Футболка базовая, белая',     350.00,  990.00, 120),
    (2, 'TS-002', 'Худи оверсайз, серое',       1200.00, 2890.00,  45),
    (3, 'TS-003', 'Носки хлопковые, 5 пар',      150.00,  490.00, 300),
    (4, 'TS-004', 'Кепка снэпбэк, чёрная',       400.00, 1290.00,   0),
    (5, 'TS-005', 'Рюкзак городской, 20 л',     1800.00, 3990.00,  18),
    (6, 'TS-006', 'Бутылка спортивная, 750 мл',  250.00,  790.00,  64);

-- В демо-режиме реальные запросы не отправляются, ключи можно не менять.
INSERT INTO `marketplace_connections` (`marketplace_type`, `api_key`, `client_id`, `warehouse_id`, `status`) VALUES
    ('wb',   'eyJhbGciOiJFUzI1NiIsImtpZCI6IjIwMjQifQ.DEMO_WB_TOKEN.signature_placeholder', NULL,     '12345', 'active'),
    ('ozon', 'demo-ozon-api-key-0000-1111-2222-secret',                                   '987654', '22222', 'active');

INSERT INTO `product_mappings` (`product_id`, `marketplace_type`, `marketplace_sku`) VALUES
    (1, 'wb', 'WB-001'), (1, 'ozon', 'OZ-001'),
    (2, 'wb', 'WB-002'), (2, 'ozon', 'OZ-002'),
    (3, 'wb', 'WB-003'), (3, 'ozon', 'OZ-003'),
    (4, 'wb', 'WB-004'), (4, 'ozon', 'OZ-004'),
    (5, 'wb', 'WB-005'), (5, 'ozon', 'OZ-005'),
    (6, 'wb', 'WB-006'), (6, 'ozon', 'OZ-006');
