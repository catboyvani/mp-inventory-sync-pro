<?php
declare(strict_types=1);

namespace App\Clients;

use App\Contracts\MarketplaceClientInterface;

/**
 * Заглушка маркетплейса для демо-режима.
 *
 * Не делает сетевых запросов и не требует реальных ключей — позволяет
 * запустить и оценить проект «из коробки». Значения подобраны под seed-данные
 * из sql/schema.sql так, чтобы дашборд показал смесь статусов:
 *  - совпадение остатка и цены  -> «Синхронизировано»;
 *  - расхождение остатка/цены   -> «Расхождение»;
 *  - отсутствие SKU в ответе    -> «Ошибка» (нет данных с площадки).
 *
 * @phpstan-type RemoteRow array{stock:int, price:float}
 */
final class MockClient implements MarketplaceClientInterface
{
    /**
     * Заранее заданные «ответы маркетплейса».
     * Ключ — marketplace_sku. Отсутствие ключа = товара нет в выдаче.
     *
     * @var array<string, array<string, array{stock:int, price:float}>>
     */
    private const DATASET = [
        'wb' => [
            'WB-001' => ['stock' => 120, 'price' => 990.0],   // всё совпадает
            'WB-002' => ['stock' => 40,  'price' => 2890.0],  // расхождение по остатку (локально 45)
            'WB-003' => ['stock' => 300, 'price' => 450.0],   // расхождение по цене (локально 490)
            'WB-004' => ['stock' => 0,   'price' => 1290.0],  // совпадает
            // 'WB-005' отсутствует намеренно -> статус «Ошибка»
            'WB-006' => ['stock' => 64,  'price' => 790.0],   // совпадает
        ],
        'ozon' => [
            'OZ-001' => ['stock' => 118, 'price' => 990.0],   // расхождение по остатку (локально 120)
            'OZ-002' => ['stock' => 45,  'price' => 2890.0],  // совпадает
            'OZ-003' => ['stock' => 300, 'price' => 490.0],   // совпадает
            'OZ-004' => ['stock' => 5,   'price' => 1290.0],  // расхождение по остатку (локально 0)
            'OZ-005' => ['stock' => 18,  'price' => 3990.0],  // совпадает
            // 'OZ-006' отсутствует намеренно -> статус «Ошибка»
        ],
    ];

    public function __construct(private readonly string $type)
    {
    }

    public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param array<int, string> $marketplaceSkus
     * @return array<string, int>
     */
    public function getStocks(array $marketplaceSkus = []): array
    {
        $rows   = self::DATASET[$this->type] ?? [];
        $result = [];
        foreach ($rows as $sku => $row) {
            if ($marketplaceSkus === [] || in_array($sku, $marketplaceSkus, true)) {
                $result[$sku] = $row['stock'];
            }
        }
        return $result;
    }

    public function updateStock(string $marketplaceSku, int $newStock): bool
    {
        // В демо-режиме «отправка» всегда успешна.
        return true;
    }

    /**
     * @param array<int, string> $marketplaceSkus
     * @return array<string, float>
     */
    public function getPrices(array $marketplaceSkus = []): array
    {
        $rows   = self::DATASET[$this->type] ?? [];
        $result = [];
        foreach ($rows as $sku => $row) {
            if ($marketplaceSkus === [] || in_array($sku, $marketplaceSkus, true)) {
                $result[$sku] = $row['price'];
            }
        }
        return $result;
    }

    public function updatePrice(string $marketplaceSku, float $newPrice): bool
    {
        return true;
    }
}
