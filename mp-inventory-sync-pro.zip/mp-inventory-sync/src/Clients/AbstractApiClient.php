<?php
declare(strict_types=1);

namespace App\Clients;

use App\Contracts\MarketplaceClientInterface;
use App\Exceptions\ApiException;
use App\Exceptions\AuthException;
use App\Exceptions\RateLimitException;

/**
 * Базовый HTTP-клиент маркетплейса на cURL.
 *
 * Инкапсулирует транспорт и единообразную обработку HTTP-статусов
 * (401/403 -> AuthException, 429 -> RateLimitException с одним авто-повтором),
 * чтобы наследники описывали только эндпоинты и формат полезной нагрузки.
 */
abstract class AbstractApiClient implements MarketplaceClientInterface
{
    private const TIMEOUT     = 20;
    private const MAX_RETRIES = 1; // один повтор при 429

    abstract protected function baseUrl(): string;

    /**
     * Заголовки авторизации конкретной площадки.
     *
     * @return array<int, string>
     */
    abstract protected function authHeaders(): array;

    /**
     * Выполнить запрос. Возвращает декодированное тело ответа.
     * $baseUrlOverride позволяет обратиться к иному хосту той же площадки
     * (например, к ценовому домену WB) без отдельного клиента.
     *
     * @param array<string, mixed>|null $payload
     * @return array<mixed>
     */
    protected function request(
        string $method,
        string $path,
        ?array $payload = null,
        ?string $baseUrlOverride = null
    ): array {
        $attempt = 0;

        do {
            $attempt++;
            [$status, $body, $retryAfter] = $this->send($method, $path, $payload, $baseUrlOverride);

            if ($status === 429 && $attempt <= self::MAX_RETRIES) {
                sleep(max(1, $retryAfter));
                continue;
            }
            break;
        } while (true);

        $this->guardStatus($status, $retryAfter);

        if ($body === '' || $body === 'null') {
            return [];
        }

        $decoded = json_decode($body, true);
        if (!is_array($decoded)) {
            throw new ApiException(
                'Некорректный JSON в ответе маркетплейса.',
                $status,
                $this->getType()
            );
        }

        return $decoded;
    }

    /**
     * Низкоуровневая отправка через cURL.
     *
     * @param array<string, mixed>|null $payload
     * @return array{0:int,1:string,2:int} [httpStatus, body, retryAfterSeconds]
     */
    private function send(string $method, string $path, ?array $payload, ?string $baseUrlOverride = null): array
    {
        $ch = curl_init();
        $headers = array_merge(['Content-Type: application/json'], $this->authHeaders());

        curl_setopt_array($ch, [
            CURLOPT_URL            => ($baseUrlOverride ?? $this->baseUrl()) . $path,
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => self::TIMEOUT,
            CURLOPT_HTTPHEADER     => $headers,
        ]);

        if ($payload !== null) {
            curl_setopt(
                $ch,
                CURLOPT_POSTFIELDS,
                json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)
            );
        }

        $raw = curl_exec($ch);

        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new ApiException(
                "Сетевая ошибка при обращении к API: {$error}",
                0,
                $this->getType()
            );
        }

        $status     = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $headerSize = (int) curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $rawHeaders = substr((string) $raw, 0, $headerSize);
        $body       = substr((string) $raw, $headerSize);
        curl_close($ch);

        $retryAfter = 1;
        if (preg_match('/retry-after:\s*(\d+)/i', $rawHeaders, $m) === 1) {
            $retryAfter = (int) $m[1];
        }

        return [$status, $body, $retryAfter];
    }

    /**
     * Перевод неуспешных HTTP-статусов в доменные исключения.
     */
    private function guardStatus(int $status, int $retryAfter): void
    {
        if ($status >= 200 && $status < 300) {
            return;
        }

        if ($status === 401 || $status === 403) {
            throw new AuthException(
                'Ошибка авторизации на маркетплейсе (проверьте токен/ключ).',
                $status,
                $this->getType()
            );
        }

        if ($status === 429) {
            throw new RateLimitException(
                'Превышен лимит запросов к маркетплейсу.',
                $retryAfter,
                $this->getType()
            );
        }

        throw new ApiException(
            "Маркетплейс вернул неожиданный статус: {$status}.",
            $status,
            $this->getType()
        );
    }
}
