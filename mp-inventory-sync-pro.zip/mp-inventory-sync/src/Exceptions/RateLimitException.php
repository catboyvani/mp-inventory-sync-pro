<?php
declare(strict_types=1);

namespace App\Exceptions;

/**
 * Превышение лимита запросов (HTTP 429).
 * Содержит рекомендованную паузу перед повтором (Retry-After), сек.
 */
final class RateLimitException extends ApiException
{
    public function __construct(
        string $message,
        public readonly int $retryAfter = 1,
        string $marketplace = ''
    ) {
        parent::__construct($message, 429, $marketplace);
    }
}
