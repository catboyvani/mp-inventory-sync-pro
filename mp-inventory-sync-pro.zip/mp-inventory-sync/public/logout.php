<?php
declare(strict_types=1);

use App\Support\Auth;

require __DIR__ . '/../bootstrap.php';

Auth::logout();
header('Location: login.php');
exit;
