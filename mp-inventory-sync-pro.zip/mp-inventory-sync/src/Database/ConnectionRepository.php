<?php
declare(strict_types=1);

namespace App\Database;

use App\Support\Crypto;
use PDO;

/**
 * Доступ к таблице marketplace_connections.
 *
 * Главная задача — единая точка шифрования секретов:
 *  - при чтении api_key / client_id расшифровываются (Crypto::decrypt);
 *  - при записи — шифруются (Crypto::encrypt).
 *
 * Благодаря этому остальной код работает с «чистыми» значениями, а в базе
 * секреты лежат только в зашифрованном виде.
 */
final class ConnectionRepository
{
    public function __construct(private readonly PDO $pdo)
    {
    }

    /**
     * Все подключения с расшифрованными секретами.
     *
     * @return array<int, array<string, mixed>>
     */
    public function all(): array
    {
        $rows = $this->pdo
            ->query('SELECT id, marketplace_type, api_key, client_id, warehouse_id, status
                       FROM marketplace_connections ORDER BY marketplace_type')
            ->fetchAll();

        return array_map([$this, 'decryptRow'], $rows);
    }

    /**
     * Только активные подключения (для синхронизации), секреты расшифрованы.
     *
     * @return array<int, array<string, mixed>>
     */
    public function active(): array
    {
        $rows = $this->pdo
            ->query("SELECT id, marketplace_type, api_key, client_id, warehouse_id
                       FROM marketplace_connections WHERE status = 'active'")
            ->fetchAll();

        return array_map([$this, 'decryptRow'], $rows);
    }

    /**
     * Создать/обновить подключение площадки. Секреты шифруются перед записью.
     * Пустой apiKey/clientId означает «не менять» существующее значение.
     */
    public function upsert(
        string $type,
        ?string $apiKey,
        ?string $clientId,
        ?string $warehouseId,
        string $status
    ): void {
        $existing = $this->findByType($type);

        $apiKeyEnc = ($apiKey !== null && $apiKey !== '')
            ? Crypto::encrypt($apiKey)
            : ($existing['api_key_raw'] ?? '');

        $clientEnc = ($clientId !== null && $clientId !== '')
            ? Crypto::encrypt($clientId)
            : ($existing['client_id_raw'] ?? null);

        if ($existing === null) {
            $stmt = $this->pdo->prepare(
                'INSERT INTO marketplace_connections
                    (marketplace_type, api_key, client_id, warehouse_id, status)
                 VALUES (:type, :api_key, :client_id, :wh, :status)'
            );
        } else {
            $stmt = $this->pdo->prepare(
                'UPDATE marketplace_connections
                    SET api_key = :api_key, client_id = :client_id,
                        warehouse_id = :wh, status = :status
                  WHERE marketplace_type = :type'
            );
        }

        $stmt->bindValue(':type', $type);
        $stmt->bindValue(':api_key', $apiKeyEnc);
        $stmt->bindValue(':client_id', $clientEnc, $clientEnc === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
        $stmt->bindValue(':wh', $warehouseId, $warehouseId === null ? PDO::PARAM_NULL : PDO::PARAM_STR);
        $stmt->bindValue(':status', $status);
        $stmt->execute();
    }

    /**
     * Найти подключение по типу, оставив СЫРЫЕ (зашифрованные) значения
     * под ключами *_raw — нужно для upsert «не менять секрет».
     *
     * @return array<string, mixed>|null
     */
    private function findByType(string $type): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT api_key, client_id FROM marketplace_connections WHERE marketplace_type = :type'
        );
        $stmt->bindValue(':type', $type);
        $stmt->execute();
        $row = $stmt->fetch();

        if ($row === false) {
            return null;
        }

        return [
            'api_key_raw'   => (string) $row['api_key'],
            'client_id_raw' => $row['client_id'] !== null ? (string) $row['client_id'] : null,
        ];
    }

    /**
     * Расшифровать секреты в строке подключения.
     *
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    private function decryptRow(array $row): array
    {
        $row['api_key'] = isset($row['api_key']) ? Crypto::decrypt((string) $row['api_key']) : '';
        if (isset($row['client_id']) && $row['client_id'] !== null && $row['client_id'] !== '') {
            $row['client_id'] = Crypto::decrypt((string) $row['client_id']);
        }
        return $row;
    }
}
