<?php
declare(strict_types=1);

namespace App\Support;

use RuntimeException;

/**
 * Симметричное шифрование чувствительных данных (API-ключи маркетплейсов).
 *
 * Алгоритм: XSalsa20-Poly1305 (sodium_crypto_secretbox) — аутентифицированное
 * шифрование. Ключ берётся из APP_KEY (.env) — 32 байта в base64.
 *
 * Формат хранимого значения:  "enc:v1:" . base64( nonce || ciphertext )
 * Если строка не имеет префикса "enc:v1:" — считается незашифрованной
 * (обратная совместимость с демо-данными и ручным вводом).
 */
final class Crypto
{
    private const PREFIX = 'enc:v1:';

    /** Сгенерировать новый ключ (для команды установки). Base64 32 байта. */
    public static function generateKey(): string
    {
        return base64_encode(random_bytes(SODIUM_CRYPTO_SECRETBOX_KEYBYTES));
    }

    /**
     * Зашифровать строку. Возвращает значение с префиксом enc:v1:.
     */
    public static function encrypt(string $plain): string
    {
        $key   = self::key();
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $cipher = sodium_crypto_secretbox($plain, $nonce, $key);

        return self::PREFIX . base64_encode($nonce . $cipher);
    }

    /**
     * Расшифровать строку. Если значение не зашифровано нашим методом —
     * вернуть его как есть (демо-плейсхолдеры, legacy-данные).
     */
    public static function decrypt(string $stored): string
    {
        if (!str_starts_with($stored, self::PREFIX)) {
            return $stored; // не зашифровано — отдаём как есть
        }

        $raw = base64_decode(substr($stored, strlen(self::PREFIX)), true);
        if ($raw === false || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
            throw new RuntimeException('Повреждённые зашифрованные данные.');
        }

        $nonce  = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $cipher = substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);

        $plain = sodium_crypto_secretbox_open($cipher, $nonce, self::key());
        if ($plain === false) {
            throw new RuntimeException('Не удалось расшифровать значение (неверный APP_KEY?).');
        }

        return $plain;
    }

    /** Уже зашифровано нашим методом? */
    public static function isEncrypted(string $value): bool
    {
        return str_starts_with($value, self::PREFIX);
    }

    /** Бинарный 32-байтный ключ из APP_KEY. */
    private static function key(): string
    {
        $b64 = (string) Env::get('APP_KEY', '');
        if ($b64 === '') {
            throw new RuntimeException(
                'APP_KEY не задан. Сгенерируйте: php bin/console.php key:generate и впишите в .env'
            );
        }

        $key = base64_decode($b64, true);
        if ($key === false || strlen($key) !== SODIUM_CRYPTO_SECRETBOX_KEYBYTES) {
            throw new RuntimeException('APP_KEY некорректен: ожидается base64 от 32 байт.');
        }

        return $key;
    }
}
