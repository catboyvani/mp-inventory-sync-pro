<?php
declare(strict_types=1);

namespace App\Support;

/**
 * Набор статических хелперов безопасности:
 *  - экранирование вывода (защита от XSS);
 *  - маскирование чувствительных данных (API-ключей);
 *  - строгая фильтрация входящих параметров.
 *
 * Защита от SQL-инъекций обеспечивается отдельно — исключительно
 * через подготовленные выражения PDO (см. App\Database\Database).
 */
final class Security
{
    /**
     * Экранирование строки для безопасного вывода в HTML.
     * Используется во всех server-rendered шаблонах.
     */
    public static function e(mixed $value): string
    {
        return htmlspecialchars(
            (string) $value,
            ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5,
            'UTF-8'
        );
    }

    /**
     * Маскирование секрета: показываем только начало и конец.
     * Пример: "api_key_secret_value" -> "api_...lue".
     */
    public static function maskSecret(?string $secret, int $head = 4, int $tail = 3): string
    {
        if ($secret === null || $secret === '') {
            return '—';
        }

        $length = strlen($secret);
        if ($length <= $head + $tail) {
            // Слишком короткий, чтобы безопасно показать края.
            return str_repeat('•', max($length, 4));
        }

        return substr($secret, 0, $head) . '...' . substr($secret, -$tail);
    }

    /**
     * Привести значение к целому числу в заданных границах.
     */
    public static function int(mixed $value, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): ?int
    {
        $filtered = filter_var($value, FILTER_VALIDATE_INT);
        if ($filtered === false) {
            return null;
        }
        return max($min, min($max, $filtered));
    }

    /**
     * Безопасная строка: обрезаем по длине и удаляем управляющие символы.
     */
    public static function string(mixed $value, int $maxLength = 255): string
    {
        $value = is_scalar($value) ? (string) $value : '';
        $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value) ?? '';
        return mb_substr(trim($value), 0, $maxLength, 'UTF-8');
    }

    /**
     * Значение должно входить в белый список, иначе вернётся $default.
     *
     * @param array<int, string> $allowed
     */
    public static function enum(mixed $value, array $allowed, ?string $default = null): ?string
    {
        $value = is_scalar($value) ? (string) $value : '';
        return in_array($value, $allowed, true) ? $value : $default;
    }
}
