<?php
declare(strict_types=1);

/**
 * tests/mock_smoke.php
 *
 * Лёгкий smoke-тест без БД и без сети: проверяет логику сравнения остатков/цен
 * и контракт MockClient. Запуск:  php tests/mock_smoke.php
 *
 * Это не PHPUnit, а минимальный самостоятельный прогон для быстрой проверки.
 */

use App\Clients\MockClient;
use App\Support\Auth;
use App\Support\Crypto;
use App\Support\Security;

require __DIR__ . '/../bootstrap.php';

$failures = 0;

/** @param mixed $actual @param mixed $expected */
function check(string $name, $actual, $expected): void
{
    global $failures;
    $ok = $actual === $expected;
    if (!$ok) {
        $failures++;
    }
    printf(
        "[%s] %s%s\n",
        $ok ? 'OK ' : 'FAIL',
        $name,
        $ok ? '' : "  (ожидали " . var_export($expected, true) . ", получили " . var_export($actual, true) . ')'
    );
}

echo "== MockClient ==\n";
$wb = new MockClient('wb');
$stocks = $wb->getStocks(['WB-001', 'WB-002', 'WB-005']);
check('WB-001 остаток = 120', $stocks['WB-001'] ?? null, 120);
check('WB-002 остаток = 40',  $stocks['WB-002'] ?? null, 40);
check('WB-005 отсутствует (ошибка)', array_key_exists('WB-005', $stocks), false);

$prices = $wb->getPrices(['WB-003']);
check('WB-003 цена = 450.0', $prices['WB-003'] ?? null, 450.0);
check('updateStock демо = true', $wb->updateStock('WB-001', 99), true);

echo "\n== Security ==\n";
check('маскирование ключа', Security::maskSecret('api_key_secret_value'), 'api_...lue');
check('экранирование XSS', Security::e('<script>'), '&lt;script&gt;');
check('enum белый список', Security::enum('wb', ['wb', 'ozon']), 'wb');
check('enum отсев', Security::enum('hack', ['wb', 'ozon'], null), null);
check('int границы', Security::int('500', 0, 100), 100);

echo "\n== Crypto (шифрование секретов) ==\n";
$secret = 'eyJhbG.SECRET.sig';
$enc = Crypto::encrypt($secret);
check('значение зашифровано (enc:v1:)', Crypto::isEncrypted($enc), true);
check('расшифровка возвращает оригинал', Crypto::decrypt($enc), $secret);
check('незашифрованное проходит как есть', Crypto::decrypt('plain-demo'), 'plain-demo');

echo "\n== Auth (пароль и CSRF) ==\n";
$hash = password_hash('s3cret', PASSWORD_BCRYPT);
check('верный пароль проходит', password_verify('s3cret', $hash), true);
check('неверный пароль отсеивается', password_verify('wrong', $hash), false);
$token = Auth::csrfToken();
check('CSRF: валидный токен принят', Auth::csrfValid($token), true);
check('CSRF: чужой токен отклонён', Auth::csrfValid('deadbeef'), false);

echo "\n";
if ($failures === 0) {
    echo "Все проверки пройдены.\n";
    exit(0);
}

echo "Провалено проверок: {$failures}\n";
exit(1);
