<?php
declare(strict_types=1);

namespace App\Clients;

/**
 * Клиент Ozon Seller API (host: https://api-seller.ozon.ru).
 *
 * Эндпоинты:
 *  - Остатки (чтение):  POST /v4/product/info/stocks
 *  - Остатки (запись):  POST /v2/products/stocks
 *  - Цены (чтение):     POST /v5/product/info/prices
 *  - Цены (запись):     POST /v1/product/import/prices
 *
 * Авторизация: заголовки Client-Id и Api-Key.
 * Идентификатор товара — offer_id продавца (хранится в marketplace_sku).
 */
final class OzonClient extends AbstractApiClient
{
    private const HOST = 'https://api-seller.ozon.ru';

    public function __construct(
        private readonly string $clientId,
        private readonly string $apiKey,
        private readonly string $warehouseId
    ) {
    }

    public function getType(): string
    {
        return 'ozon';
    }

    protected function baseUrl(): string
    {
        return self::HOST;
    }

    /** @return array<int, string> */
    protected function authHeaders(): array
    {
        return [
            'Client-Id: ' . $this->clientId,
            'Api-Key: '   . $this->apiKey,
        ];
    }

    /**
     * POST /v4/product/info/stocks
     * Ответ: {"items":[{"offer_id":"...","stocks":[{"present":N,"reserved":M,"type":"fbs"}]}]}
     *
     * @param array<int, string> $marketplaceSkus
     * @return array<string, int>
     */
    public function getStocks(array $marketplaceSkus = []): array
    {
        $result = [];
        $cursor = '';
        $guard  = 0;

        do {
            $response = $this->request('POST', '/v4/product/info/stocks', [
                'filter' => ['offer_id' => array_values($marketplaceSkus), 'visibility' => 'ALL'],
                'limit'  => 1000,
                'cursor' => $cursor,
            ]);

            $items = $response['items'] ?? $response['result']['items'] ?? [];
            foreach ($items as $item) {
                $offerId = (string) ($item['offer_id'] ?? '');
                if ($offerId === '') {
                    continue;
                }
                $available = 0;
                foreach (($item['stocks'] ?? []) as $stock) {
                    $available += (int) ($stock['present'] ?? 0) - (int) ($stock['reserved'] ?? 0);
                }
                $result[$offerId] = max(0, $available);
            }

            $cursor = (string) ($response['cursor'] ?? '');
            $guard++;
        } while ($cursor !== '' && $items !== [] && $guard < 50);

        return $result;
    }

    /**
     * POST /v2/products/stocks
     * body: {"stocks":[{"offer_id":"...","stock":N,"warehouse_id":...}]}
     */
    public function updateStock(string $marketplaceSku, int $newStock): bool
    {
        $response = $this->request('POST', '/v2/products/stocks', [
            'stocks' => [[
                'offer_id'     => $marketplaceSku,
                'stock'        => $newStock,
                'warehouse_id' => (int) $this->warehouseId,
            ]],
        ]);

        foreach (($response['result'] ?? []) as $row) {
            if (($row['updated'] ?? false) === true) {
                return true;
            }
        }

        return false;
    }

    /**
     * POST /v5/product/info/prices
     * Ответ: {"items":[{"offer_id":"...","price":{"price":"999.0000"}}]}
     *
     * @param array<int, string> $marketplaceSkus
     * @return array<string, float>
     */
    public function getPrices(array $marketplaceSkus = []): array
    {
        $result = [];
        $cursor = '';
        $guard  = 0;

        do {
            $response = $this->request('POST', '/v5/product/info/prices', [
                'filter' => ['offer_id' => array_values($marketplaceSkus), 'visibility' => 'ALL'],
                'limit'  => 1000,
                'cursor' => $cursor,
            ]);

            $items = $response['items'] ?? $response['result']['items'] ?? [];
            foreach ($items as $item) {
                $offerId = (string) ($item['offer_id'] ?? '');
                if ($offerId === '') {
                    continue;
                }
                $result[$offerId] = (float) ($item['price']['price'] ?? 0);
            }

            $cursor = (string) ($response['cursor'] ?? '');
            $guard++;
        } while ($cursor !== '' && $items !== [] && $guard < 50);

        return $result;
    }

    /**
     * POST /v1/product/import/prices
     * body: {"prices":[{"offer_id":"...","price":"999"}]}
     */
    public function updatePrice(string $marketplaceSku, float $newPrice): bool
    {
        $response = $this->request('POST', '/v1/product/import/prices', [
            'prices' => [[
                'offer_id' => $marketplaceSku,
                'price'    => (string) (int) round($newPrice),
            ]],
        ]);

        foreach (($response['result'] ?? []) as $row) {
            if (($row['updated'] ?? false) === true) {
                return true;
            }
        }

        return false;
    }
}
