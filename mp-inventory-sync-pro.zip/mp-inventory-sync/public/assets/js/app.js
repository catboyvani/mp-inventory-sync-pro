'use strict';

/**
 * app.js — асинхронный дашборд синхронизации (Vanilla JS, ES6+, Fetch API).
 * Без сторонних библиотек. Обновляет таблицу и статусы без перезагрузки.
 */

const STATUS_META = {
    synced:   { label: 'Синхронизировано', cls: 'text-bg-success' },
    mismatch: { label: 'Расхождение',      cls: 'text-bg-warning' },
    error:    { label: 'Ошибка',           cls: 'text-bg-danger' },
    pending:  { label: 'Не проверено',     cls: 'text-bg-secondary' },
    'n/a':    { label: '—',                cls: 'text-bg-secondary' },
};

const els = {
    btn:        document.getElementById('syncBtn'),
    btnText:    document.getElementById('syncBtnText'),
    spinner:    document.getElementById('syncSpinner'),
    tableBody:  document.querySelector('#productsTable tbody'),
    errorBox:   document.getElementById('errorBox'),
    meta:       document.getElementById('syncMeta'),
};

els.btn.addEventListener('click', runSync);

/** Запустить синхронизацию: блокируем кнопку, бьём в API, рендерим ответ. */
async function runSync() {
    setLoading(true);
    hideError();

    try {
        const csrf = document.querySelector('meta[name="csrf-token"]')?.content || '';
        const response = await fetch('api/sync.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRF-Token': csrf,
            },
            body: 'csrf=' + encodeURIComponent(csrf),
        });

        if (response.status === 401) {
            // Сессия истекла — отправляем на страницу входа.
            window.location.href = 'login.php';
            return;
        }

        const payload = await response.json();

        if (!response.ok || !payload.ok) {
            throw new Error(payload.error || `HTTP ${response.status}`);
        }

        renderRows(payload.data);
        renderSummary(payload.summary);
        renderMeta(payload.summary);
    } catch (err) {
        showError(`Не удалось синхронизировать: ${err.message}`);
    } finally {
        setLoading(false);
    }
}

/** Переключить состояние загрузки кнопки. */
function setLoading(isLoading) {
    els.btn.disabled = isLoading;
    els.spinner.classList.toggle('d-none', !isLoading);
    els.btnText.textContent = isLoading ? 'Синхронизация…' : 'Запустить синхронизацию';
}

/** Отрисовать строки таблицы по данным API. */
function renderRows(rows) {
    if (!Array.isArray(rows)) {
        return;
    }

    rows.forEach((row) => {
        let tr = els.tableBody.querySelector(`tr[data-product="${row.product_id}"]`);
        if (!tr) {
            tr = buildRow(row);
            els.tableBody.appendChild(tr);
        }

        setCellText(tr, 'local_stock', row.local_stock);
        setCellText(tr, 'local_price', formatPrice(row.local_price));
        setCellText(tr, 'wb_stock',  row.wb_stock  ?? '—');
        setCellText(tr, 'ozon_stock', row.ozon_stock ?? '—');
        setCellBadge(tr, 'wb_status',  row.wb_status);
        setCellBadge(tr, 'ozon_status', row.ozon_status);

        // Кратко подсветим обновлённую строку.
        tr.classList.remove('row-updated');
        void tr.offsetWidth; // перезапуск анимации
        tr.classList.add('row-updated');
    });
}

/** Создать новую строку (если товара ещё не было в начальной отрисовке). */
function buildRow(row) {
    const tr = document.createElement('tr');
    tr.dataset.product = String(row.product_id);

    // textContent защищает от XSS — пользовательские данные не парсятся как HTML.
    const name = document.createElement('td');
    name.textContent = row.name ?? '';

    const sku = document.createElement('td');
    const code = document.createElement('code');
    code.textContent = row.sku ?? '';
    sku.appendChild(code);

    tr.append(name, sku);
    ['local_stock', 'local_price', 'wb_stock', 'ozon_stock'].forEach((col) => {
        const td = document.createElement('td');
        td.className = 'text-end';
        td.dataset.col = col;
        tr.appendChild(td);
    });
    ['wb_status', 'ozon_status'].forEach((col) => {
        const td = document.createElement('td');
        td.dataset.col = col;
        tr.appendChild(td);
    });

    return tr;
}

function setCellText(tr, col, value) {
    const cell = tr.querySelector(`[data-col="${col}"]`);
    if (cell) {
        cell.textContent = value;
    }
}

function setCellBadge(tr, col, status) {
    const cell = tr.querySelector(`[data-col="${col}"]`);
    if (!cell) {
        return;
    }
    const meta = STATUS_META[status] || STATUS_META.pending;
    cell.innerHTML = '';
    const badge = document.createElement('span');
    badge.className = `badge ${meta.cls}`;
    badge.textContent = meta.label;
    cell.appendChild(badge);
}

/** Обновить карточки сводки. */
function renderSummary(summary) {
    if (!summary) {
        return;
    }
    ['total', 'synced', 'mismatch', 'error'].forEach((key) => {
        const el = document.querySelector(`[data-stat="${key}"]`);
        if (el) {
            el.textContent = summary[key] ?? 0;
        }
    });
}

/** Показать дату прогона и предупреждения по API. */
function renderMeta(summary) {
    if (!summary) {
        return;
    }
    const parts = [];
    if (summary.generated_at) {
        const dt = new Date(summary.generated_at);
        parts.push(`обновлено ${dt.toLocaleString('ru-RU')}`);
    }
    if (summary.demo_mode) {
        parts.push('demo-режим');
    }
    if (summary.auto_push) {
        parts.push('авто-пуш включён');
    }
    els.meta.textContent = parts.join(' · ');

    const apiErrors = summary.api_errors || {};
    const errorKeys = Object.keys(apiErrors);
    if (errorKeys.length > 0) {
        const msg = errorKeys.map((k) => `${k.toUpperCase()}: ${apiErrors[k]}`).join('; ');
        showError(`Часть площадок ответила с ошибкой — ${msg}`);
    }
}

function formatPrice(value) {
    const num = Number(value) || 0;
    return num.toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function showError(message) {
    els.errorBox.textContent = message;
    els.errorBox.classList.remove('d-none');
}

function hideError() {
    els.errorBox.classList.add('d-none');
    els.errorBox.textContent = '';
}
