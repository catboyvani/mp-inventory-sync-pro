<?php
declare(strict_types=1);

/**
 * public/index.php — дашборд синхронизации (Bootstrap 5, тёмная тема).
 *
 * Сервер отрисовывает первичное состояние (товары из БД + маскированные
 * подключения). Дальнейшее обновление таблицы — асинхронно через api/sync.php.
 */

use App\Database\ConnectionRepository;
use App\Database\Database;
use App\Support\Auth;
use App\Support\Env;
use App\Support\Security;

require __DIR__ . '/../bootstrap.php';

Auth::requireWeb();

$products    = [];
$connections = [];
$dbError     = null;

try {
    $pdo = Database::connection();

    // Связки агрегируем по товару для первичной отрисовки.
    $products = $pdo->query(
        "SELECT p.id, p.sku, p.name, p.current_stock, p.retail_price,
                MAX(CASE WHEN m.marketplace_type = 'wb'   THEN m.last_remote_stock END) AS wb_stock,
                MAX(CASE WHEN m.marketplace_type = 'ozon' THEN m.last_remote_stock END) AS ozon_stock,
                MAX(CASE WHEN m.marketplace_type = 'wb'   THEN m.sync_status END)        AS wb_status,
                MAX(CASE WHEN m.marketplace_type = 'ozon' THEN m.sync_status END)        AS ozon_status
           FROM products p
           LEFT JOIN product_mappings m ON m.product_id = p.id
          GROUP BY p.id, p.sku, p.name, p.current_stock, p.retail_price
          ORDER BY p.id"
    )->fetchAll();

    $connections = (new ConnectionRepository($pdo))->all();
} catch (Throwable $e) {
    $dbError = 'Нет соединения с БД. Проверьте .env и импорт sql/schema.sql.';
}

$isDemo   = Env::bool('APP_DEMO_MODE', true);
$csrfToken = Auth::csrfToken();

/** Подпись статуса для Bootstrap-badge. */
function statusBadge(?string $status): string
{
    return match ($status) {
        'synced'   => '<span class="badge text-bg-success">Синхронизировано</span>',
        'mismatch' => '<span class="badge text-bg-warning">Расхождение</span>',
        'error'    => '<span class="badge text-bg-danger">Ошибка</span>',
        default    => '<span class="badge text-bg-secondary">Не проверено</span>',
    };
}
?>
<!doctype html>
<html lang="ru" data-bs-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= Security::e($csrfToken) ?>">
    <title>MP Inventory Sync — остатки и цены WB / Ozon</title>
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
        crossorigin="anonymous">
    <link href="assets/css/app.css" rel="stylesheet">
</head>
<body class="bg-body">
<nav class="navbar border-bottom border-secondary-subtle mb-4">
    <div class="container-xl">
        <span class="navbar-brand d-flex align-items-center gap-2 mb-0">
            <span class="brand-dot"></span>
            MP Inventory Sync
        </span>
        <?php if ($isDemo): ?>
            <span class="badge text-bg-info">DEMO-режим (без реальных ключей)</span>
        <?php endif; ?>
        <div class="d-flex gap-2 align-items-center">
            <a href="settings.php" class="btn btn-sm btn-outline-secondary">Настройки</a>
            <a href="logout.php" class="btn btn-sm btn-outline-danger">Выйти</a>
        </div>
    </div>
</nav>

<main class="container-xl pb-5">

    <?php if ($dbError !== null): ?>
        <div class="alert alert-danger"><?= Security::e($dbError) ?></div>
    <?php endif; ?>

    <div class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-3">
        <div>
            <h1 class="h4 mb-1">Синхронизация остатков и цен</h1>
            <p class="text-secondary mb-0">
                Сверка локального склада с личными кабинетами Wildberries и Ozon.
            </p>
        </div>
        <button id="syncBtn" class="btn btn-primary px-4">
            <span id="syncSpinner" class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true"></span>
            <span id="syncBtnText">Запустить синхронизацию</span>
        </button>
    </div>

    <!-- Сводка -->
    <div class="row g-3 mb-4" id="summary">
        <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body"><div class="stat-label">Товаров</div><div class="stat-value" data-stat="total">—</div></div></div></div>
        <div class="col-6 col-md-3"><div class="card stat-card border-success-subtle"><div class="card-body"><div class="stat-label text-success">Синхронизировано</div><div class="stat-value" data-stat="synced">—</div></div></div></div>
        <div class="col-6 col-md-3"><div class="card stat-card border-warning-subtle"><div class="card-body"><div class="stat-label text-warning">Расхождений</div><div class="stat-value" data-stat="mismatch">—</div></div></div></div>
        <div class="col-6 col-md-3"><div class="card stat-card border-danger-subtle"><div class="card-body"><div class="stat-label text-danger">Ошибок</div><div class="stat-value" data-stat="error">—</div></div></div></div>
    </div>

    <!-- Таблица -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span>Товары</span>
            <small id="syncMeta" class="text-secondary"></small>
        </div>
        <div class="table-responsive">
            <table class="table table-dark table-hover align-middle mb-0" id="productsTable">
                <thead>
                    <tr>
                        <th>Название</th>
                        <th>Артикул</th>
                        <th class="text-end">Склад<br><small class="text-secondary">локальный</small></th>
                        <th class="text-end">Цена<br><small class="text-secondary">локальная</small></th>
                        <th class="text-end">Остаток WB</th>
                        <th class="text-end">Остаток Ozon</th>
                        <th>Статус WB</th>
                        <th>Статус Ozon</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($products as $p): ?>
                    <tr data-product="<?= (int) $p['id'] ?>">
                        <td><?= Security::e($p['name']) ?></td>
                        <td><code><?= Security::e($p['sku']) ?></code></td>
                        <td class="text-end" data-col="local_stock"><?= (int) $p['current_stock'] ?></td>
                        <td class="text-end" data-col="local_price"><?= Security::e(number_format((float) $p['retail_price'], 2, '.', ' ')) ?></td>
                        <td class="text-end" data-col="wb_stock"><?= $p['wb_stock'] === null ? '—' : (int) $p['wb_stock'] ?></td>
                        <td class="text-end" data-col="ozon_stock"><?= $p['ozon_stock'] === null ? '—' : (int) $p['ozon_stock'] ?></td>
                        <td data-col="wb_status"><?= statusBadge($p['wb_status']) ?></td>
                        <td data-col="ozon_status"><?= statusBadge($p['ozon_status']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Подключения (демонстрация маскирования ключей) -->
    <div class="card mt-4">
        <div class="card-header">Подключения к маркетплейсам</div>
        <ul class="list-group list-group-flush">
            <?php foreach ($connections as $c): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <span class="fw-semibold text-uppercase"><?= Security::e($c['marketplace_type']) ?></span>
                    <span class="text-secondary">
                        ключ: <code><?= Security::e(Security::maskSecret($c['api_key'])) ?></code>
                        <?php if (!empty($c['client_id'])): ?>
                            · Client-Id: <code><?= Security::e(Security::maskSecret($c['client_id'])) ?></code>
                        <?php endif; ?>
                    </span>
                    <span class="badge <?= $c['status'] === 'active' ? 'text-bg-success' : 'text-bg-secondary' ?>">
                        <?= Security::e($c['status']) ?>
                    </span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div id="errorBox" class="alert alert-danger mt-4 d-none" role="alert"></div>
</main>

<script src="assets/js/app.js"></script>
</body>
</html>
