<?php
declare(strict_types=1);

namespace App\Exceptions;

use RuntimeException;

/**
 * Базовое исключение слоя интеграции с маркетплейсами.
 * Хранит HTTP-статус ответа для диагностики.
 */
class ApiException extends RuntimeException
{
    public function __construct(
        string $message,
        public readonly int $httpStatus = 0,
        public readonly string $marketplace = ''
    ) {
        parent::__construct($message);
    }
}
