<?php
declare(strict_types=1);

namespace App\Database;

use App\Support\Env;
use PDO;
use PDOException;
use RuntimeException;

/**
 * Фабрика PDO-подключения к MySQL.
 *
 * Конфигурация ориентирована на безопасность:
 *  - ERRMODE_EXCEPTION — ошибки не глотаются молча;
 *  - EMULATE_PREPARES = false — настоящие серверные prepared statements,
 *    что вместе с bind-параметрами полностью исключает SQL-инъекции;
 *  - FETCH_ASSOC по умолчанию.
 */
final class Database
{
    private static ?PDO $instance = null;

    /** Утилитарный класс — экземпляры не создаём. */
    private function __construct()
    {
    }

    public static function connection(): PDO
    {
        if (self::$instance instanceof PDO) {
            return self::$instance;
        }

        $host    = (string) Env::get('DB_HOST', '127.0.0.1');
        $port    = (string) Env::get('DB_PORT', '3306');
        $dbName  = (string) Env::get('DB_NAME', 'mp_sync');
        $user    = (string) Env::get('DB_USER', 'root');
        $pass    = (string) Env::get('DB_PASS', '');
        $charset = (string) Env::get('DB_CHARSET', 'utf8mb4');

        $dsn = "mysql:host={$host};port={$port};dbname={$dbName};charset={$charset}";

        try {
            self::$instance = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_STRINGIFY_FETCHES  => false,
            ]);
        } catch (PDOException $e) {
            // Наружу не отдаём детали подключения.
            throw new RuntimeException('Не удалось подключиться к базе данных.', 0, $e);
        }

        return self::$instance;
    }
}
