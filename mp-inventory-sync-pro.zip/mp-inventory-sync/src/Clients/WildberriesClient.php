<?php
declare(strict_types=1);

namespace App\Clients;

/**
 * Клиент API Wildberries.
 *
 * Эндпоинты (актуальны на 2025–2026):
 *  - Остатки:  POST/PUT https://marketplace-api.wildberries.ru/api/v3/stocks/{warehouseId}
 *  - Цены:     POST     https://discounts-prices-api.wildberries.ru/api/v2/upload/task
 *  - Список цен: POST   https://discounts-prices-api.wildberries.ru/api/v2/list/goods/filter
 *
 * Авторизация: заголовок Authorization с токеном категории Marketplace/Prices.
 *
 * Примечание: WB оперирует баркодами (sku) для остатков и nmID для цен.
 * В демо-учебном проекте marketplace_sku трактуется как баркод; для цен
 * используется тот же идентификатор. В боевой интеграции маппинг nmID<->sku
 * стоит хранить в product_mappings отдельным полем.
 */
final class WildberriesClient extends AbstractApiClient
{
    private const HOST_MARKETPLACE = 'https://marketplace-api.wildberries.ru';
    private const HOST_PRICES      = 'https://discounts-prices-api.wildberries.ru';

    public function __construct(
        private readonly string $token,
        private readonly string $warehouseId
    ) {
    }

    public function getType(): string
    {
        return 'wb';
    }

    protected function baseUrl(): string
    {
        return self::HOST_MARKETPLACE;
    }

    /** @return array<int, string> */
    protected function authHeaders(): array
    {
        return ['Authorization: ' . $this->token];
    }

    /**
     * POST /api/v3/stocks/{warehouseId}  body: {"skus":[...]}
     * Ответ: {"stocks":[{"sku":"...","amount":10}, ...]}
     *
     * @param array<int, string> $marketplaceSkus
     * @return array<string, int>
     */
    public function getStocks(array $marketplaceSkus = []): array
    {
        if ($marketplaceSkus === []) {
            return [];
        }

        $response = $this->request(
            'POST',
            "/api/v3/stocks/{$this->warehouseId}",
            ['skus' => array_values($marketplaceSkus)]
        );

        $result = [];
        foreach (($response['stocks'] ?? []) as $item) {
            if (isset($item['sku'])) {
                $result[(string) $item['sku']] = (int) ($item['amount'] ?? 0);
            }
        }

        return $result;
    }

    /**
     * PUT /api/v3/stocks/{warehouseId}  body: {"stocks":[{"sku":"...","amount":N}]}
     */
    public function updateStock(string $marketplaceSku, int $newStock): bool
    {
        $this->request(
            'PUT',
            "/api/v3/stocks/{$this->warehouseId}",
            ['stocks' => [['sku' => $marketplaceSku, 'amount' => $newStock]]]
        );

        // WB на успешное обновление отвечает 204 No Content.
        return true;
    }

    /**
     * Цены живут на отдельном хосте. Список товаров с ценами выгружается
     * постранично (limit/offset) — поддержка больших каталогов.
     * POST /api/v2/list/goods/filter
     *
     * Возвращается карта nmID => цена (для WB цены привязаны к nmID).
     *
     * @param array<int, string> $nmIds список nmID (строками)
     * @return array<string, float>
     */
    public function getPrices(array $nmIds = []): array
    {
        $wanted = $nmIds === [] ? [] : array_flip($nmIds);
        $result = [];
        $offset = 0;
        $limit  = 1000;
        $guard  = 0;

        do {
            $response = $this->priceRequest(
                'POST',
                '/api/v2/list/goods/filter',
                ['limit' => $limit, 'offset' => $offset]
            );

            $batch = $response['data']['listGoods'] ?? [];
            foreach ($batch as $item) {
                $nmId = (string) ($item['nmID'] ?? '');
                if ($nmId === '') {
                    continue;
                }
                if ($wanted !== [] && !isset($wanted[$nmId])) {
                    continue;
                }
                $price = $item['sizes'][0]['discountedPrice']
                    ?? $item['sizes'][0]['price']
                    ?? ($item['price'] ?? 0);
                $result[$nmId] = (float) $price;
            }

            $offset += $limit;
            $guard++;
            // Останавливаемся, когда страница неполная или достигнут потолок (защита).
        } while (count($batch) === $limit && $guard < 50);

        return $result;
    }

    /**
     * POST /api/v2/upload/task  body: {"data":[{"nmID":..,"price":..}]}
     * Цена отправляется в рублях (целое).
     */
    public function updatePrice(string $nmId, float $newPrice): bool
    {
        $this->priceRequest(
            'POST',
            '/api/v2/upload/task',
            ['data' => [['nmID' => (int) $nmId, 'price' => (int) round($newPrice)]]]
        );

        return true;
    }

    /**
     * Запрос к ценовому хосту WB (отличается base URL, заголовки те же).
     *
     * @param array<string, mixed>|null $payload
     * @return array<mixed>
     */
    private function priceRequest(string $method, string $path, ?array $payload = null): array
    {
        return $this->request($method, $path, $payload, self::HOST_PRICES);
    }
}
