<?php
declare(strict_types=1);

namespace App\Contracts;

/**
 * Единый контракт клиента маркетплейса.
 *
 * Реализации (WildberriesClient, OzonClient, MockClient) скрывают за собой
 * различия конкретных REST-API, а сервис синхронизации работает только
 * с этим интерфейсом — это позволяет добавлять новые площадки без правок
 * бизнес-логики.
 *
 * Методы остатков и цен принимают список SKU маркетплейса, чтобы запрашивать
 * данные пакетно (за один HTTP-запрос вместо N).
 */
interface MarketplaceClientInterface
{
    /**
     * Получить остатки по списку SKU маркетплейса.
     *
     * @param array<int, string> $marketplaceSkus
     * @return array<string, int> Карта: marketplaceSku => остаток.
     *                            Отсутствующий в ответе SKU в карту не попадает.
     */
    public function getStocks(array $marketplaceSkus = []): array;

    /**
     * Установить новый остаток для конкретного SKU.
     */
    public function updateStock(string $marketplaceSku, int $newStock): bool;

    /**
     * Получить цены по списку SKU маркетплейса.
     *
     * @param array<int, string> $marketplaceSkus
     * @return array<string, float> Карта: marketplaceSku => цена.
     */
    public function getPrices(array $marketplaceSkus = []): array;

    /**
     * Установить новую цену для конкретного SKU.
     */
    public function updatePrice(string $marketplaceSku, float $newPrice): bool;

    /**
     * Тип площадки: 'wb' | 'ozon' | 'mock'.
     */
    public function getType(): string;
}
