<?php
declare(strict_types=1);

use App\Support\Auth;
use App\Support\Security;

require __DIR__ . '/../bootstrap.php';

Auth::startSession();

$error = null;

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    if (!Auth::csrfValid($_POST['csrf'] ?? null)) {
        $error = 'Сессия устарела, попробуйте ещё раз.';
    } else {
        $user = Security::string($_POST['username'] ?? '', 128);
        $pass = (string) ($_POST['password'] ?? '');
        if (Auth::attempt($user, $pass)) {
            header('Location: index.php');
            exit;
        }
        $error = 'Неверный логин или пароль.';
    }
}

if (Auth::check()) {
    header('Location: index.php');
    exit;
}

$csrf = Auth::csrfToken();
?>
<!doctype html>
<html lang="ru" data-bs-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Вход — MP Inventory Sync</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="assets/css/app.css" rel="stylesheet">
</head>
<body class="bg-body">
<main class="container" style="max-width: 420px; margin-top: 12vh;">
    <div class="text-center mb-4">
        <span class="brand-dot d-inline-block align-middle"></span>
        <span class="h4 align-middle ms-2">MP Inventory Sync</span>
    </div>
    <div class="card">
        <div class="card-body">
            <h1 class="h5 mb-3">Вход в систему</h1>
            <?php if ($error !== null): ?>
                <div class="alert alert-danger py-2"><?= Security::e($error) ?></div>
            <?php endif; ?>
            <form method="post" action="login.php">
                <input type="hidden" name="csrf" value="<?= Security::e($csrf) ?>">
                <div class="mb-3">
                    <label class="form-label">Логин</label>
                    <input type="text" name="username" class="form-control" autocomplete="username" autofocus required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Пароль</label>
                    <input type="password" name="password" class="form-control" autocomplete="current-password" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Войти</button>
            </form>
        </div>
    </div>
    <p class="text-secondary small text-center mt-3">
        Доступ только для администратора магазина.
    </p>
</main>
</body>
</html>
