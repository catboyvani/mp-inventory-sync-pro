<?php
declare(strict_types=1);

use App\Database\ConnectionRepository;
use App\Database\Database;
use App\Support\Auth;
use App\Support\Security;

require __DIR__ . '/../bootstrap.php';

Auth::requireWeb();

$notice = null;
$error  = null;

try {
    $repo = new ConnectionRepository(Database::connection());

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        if (!Auth::csrfValid($_POST['csrf'] ?? null)) {
            $error = 'Сессия устарела, обновите страницу и попробуйте снова.';
        } else {
            $type = Security::enum($_POST['marketplace_type'] ?? '', ['wb', 'ozon'], null);
            if ($type === null) {
                $error = 'Неизвестная площадка.';
            } else {
                $repo->upsert(
                    $type,
                    Security::string($_POST['api_key'] ?? '', 512),
                    Security::string($_POST['client_id'] ?? '', 64),
                    Security::string($_POST['warehouse_id'] ?? '', 64),
                    Security::enum($_POST['status'] ?? 'active', ['active', 'inactive'], 'active')
                );
                $notice = 'Подключение «' . strtoupper($type) . '» сохранено. Секреты зашифрованы.';
            }
        }
    }

    $connections = [];
    foreach ($repo->all() as $c) {
        $connections[$c['marketplace_type']] = $c;
    }
} catch (Throwable $e) {
    $error = 'Ошибка работы с настройками: ' . $e->getMessage();
    $connections = [];
}

$csrf = Auth::csrfToken();

function connField(array $conns, string $type, string $field): string
{
    return (string) ($conns[$type][$field] ?? '');
}
?>
<!doctype html>
<html lang="ru" data-bs-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Настройки — MP Inventory Sync</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="assets/css/app.css" rel="stylesheet">
</head>
<body class="bg-body">
<nav class="navbar border-bottom border-secondary-subtle mb-4">
    <div class="container-xl">
        <span class="navbar-brand d-flex align-items-center gap-2 mb-0">
            <span class="brand-dot"></span> MP Inventory Sync
        </span>
        <div class="d-flex gap-2">
            <a href="index.php" class="btn btn-sm btn-outline-secondary">← Дашборд</a>
            <a href="logout.php" class="btn btn-sm btn-outline-danger">Выйти</a>
        </div>
    </div>
</nav>

<main class="container-xl pb-5" style="max-width: 820px;">
    <h1 class="h4 mb-3">Подключения к маркетплейсам</h1>
    <p class="text-secondary">
        Ключи доступа сохраняются <strong>в зашифрованном виде</strong>. Оставьте поле ключа пустым,
        чтобы не менять уже сохранённое значение.
    </p>

    <?php if ($notice !== null): ?>
        <div class="alert alert-success py-2"><?= Security::e($notice) ?></div>
    <?php endif; ?>
    <?php if ($error !== null): ?>
        <div class="alert alert-danger py-2"><?= Security::e($error) ?></div>
    <?php endif; ?>

    <!-- Wildberries -->
    <div class="card mb-4">
        <div class="card-header">Wildberries</div>
        <div class="card-body">
            <form method="post" action="settings.php">
                <input type="hidden" name="csrf" value="<?= Security::e($csrf) ?>">
                <input type="hidden" name="marketplace_type" value="wb">
                <div class="mb-3">
                    <label class="form-label">API-токен (Authorization)</label>
                    <input type="password" name="api_key" class="form-control"
                           placeholder="<?= connField($connections, 'wb', 'api_key') !== '' ? '•••••• (сохранён, оставьте пустым чтобы не менять)' : 'Вставьте JWT-токен WB' ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">warehouse_id (номер склада WB)</label>
                    <input type="text" name="warehouse_id" class="form-control"
                           value="<?= Security::e(connField($connections, 'wb', 'warehouse_id')) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Статус</label>
                    <select name="status" class="form-select">
                        <option value="active"   <?= connField($connections, 'wb', 'status') !== 'inactive' ? 'selected' : '' ?>>active</option>
                        <option value="inactive" <?= connField($connections, 'wb', 'status') === 'inactive' ? 'selected' : '' ?>>inactive</option>
                    </select>
                </div>
                <button class="btn btn-primary">Сохранить Wildberries</button>
            </form>
        </div>
    </div>

    <!-- Ozon -->
    <div class="card mb-4">
        <div class="card-header">Ozon</div>
        <div class="card-body">
            <form method="post" action="settings.php">
                <input type="hidden" name="csrf" value="<?= Security::e($csrf) ?>">
                <input type="hidden" name="marketplace_type" value="ozon">
                <div class="mb-3">
                    <label class="form-label">Api-Key</label>
                    <input type="password" name="api_key" class="form-control"
                           placeholder="<?= connField($connections, 'ozon', 'api_key') !== '' ? '•••••• (сохранён, оставьте пустым чтобы не менять)' : 'Вставьте Api-Key Ozon' ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Client-Id</label>
                    <input type="text" name="client_id" class="form-control"
                           value="<?= Security::e(connField($connections, 'ozon', 'client_id')) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">warehouse_id (номер склада Ozon)</label>
                    <input type="text" name="warehouse_id" class="form-control"
                           value="<?= Security::e(connField($connections, 'ozon', 'warehouse_id')) ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Статус</label>
                    <select name="status" class="form-select">
                        <option value="active"   <?= connField($connections, 'ozon', 'status') !== 'inactive' ? 'selected' : '' ?>>active</option>
                        <option value="inactive" <?= connField($connections, 'ozon', 'status') === 'inactive' ? 'selected' : '' ?>>inactive</option>
                    </select>
                </div>
                <button class="btn btn-primary">Сохранить Ozon</button>
            </form>
        </div>
    </div>
</main>
</body>
</html>
