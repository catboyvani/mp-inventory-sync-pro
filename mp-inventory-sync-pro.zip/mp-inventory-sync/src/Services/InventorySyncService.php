<?php
declare(strict_types=1);

namespace App\Services;

use App\Contracts\MarketplaceClientInterface;
use App\Database\ConnectionRepository;
use App\Exceptions\ApiException;
use App\Factory\MarketplaceClientFactory;
use App\Support\Env;
use PDO;
use Throwable;

/**
 * Управляющий сервис синхронизации остатков и цен.
 *
 * Алгоритм run():
 *  1. читает активные подключения (секреты расшифровываются репозиторием);
 *  2. читает связки товаров (product_mappings JOIN products);
 *  3. пакетно запрашивает остатки и цены по каждому маркетплейсу
 *     (с пагинацией для больших каталогов);
 *  4. сравнивает данные площадки с локальным складом (источник истины);
 *  5. при расхождении (если включён авто-пуш) отправляет локальные значения;
 *  6. сохраняет статус в product_mappings и факт прогона в sync_runs;
 *  7. возвращает агрегированный по товарам результат для дашборда.
 *
 * Идентификаторы WB: остатки — по баркоду (marketplace_sku), цены — по nmID
 * (поле nm_id). Для Ozon оба идентификатора — offer_id (marketplace_sku).
 */
final class InventorySyncService
{
    /** Допустимая погрешность сравнения цен (копейки округления). */
    private const PRICE_EPSILON = 0.01;

    private bool $autoPush;

    public function __construct(
        private readonly PDO $pdo,
        private readonly MarketplaceClientFactory $factory
    ) {
        $this->autoPush = Env::bool('APP_AUTO_PUSH', false);
    }

    /**
     * Запустить синхронизацию.
     *
     * @param string $source 'web' | 'cron' — откуда запущено (для журнала).
     * @return array{rows: array<int, array<string, mixed>>, summary: array<string, mixed>}
     */
    public function run(string $source = 'web'): array
    {
        $clients  = $this->buildClients();
        $mappings = $this->loadMappings();

        // Пакетно тянем данные по каждому типу площадки (с пагинацией внутри клиента).
        $remote = [];
        $remoteErrors = [];
        foreach ($clients as $type => $client) {
            $stockIds = $this->collectStockIds($mappings, $type);
            $priceIds = $this->collectPriceIds($mappings, $type);
            try {
                $remote[$type] = [
                    'stocks' => $client->getStocks($stockIds),
                    'prices' => $client->getPrices($priceIds),
                ];
            } catch (ApiException $e) {
                // Падение одной площадки не должно валить весь прогон.
                $remote[$type]       = ['stocks' => [], 'prices' => []];
                $remoteErrors[$type] = $e->getMessage();
            }
        }

        $rows = [];
        foreach ($mappings as $map) {
            $productId = (int) $map['product_id'];
            $rows[$productId] ??= $this->newRow($map);

            $type   = (string) $map['marketplace_type'];
            $result = $this->evaluateMapping($map, $clients[$type] ?? null, $remote[$type] ?? null);

            $rows[$productId][$type . '_stock']  = $result['stock'];
            $rows[$productId][$type . '_price']  = $result['price'];
            $rows[$productId][$type . '_status'] = $result['status'];

            $this->persistMapping((int) $map['id'], $result);
        }

        foreach ($rows as &$row) {
            $row['status'] = $this->overallStatus([
                $row['wb_status'] ?? 'n/a',
                $row['ozon_status'] ?? 'n/a',
            ]);
        }
        unset($row);

        $rows    = array_values($rows);
        $summary = $this->buildSummary($rows, $remoteErrors);

        $this->recordRun($summary, $source);

        return ['rows' => $rows, 'summary' => $summary];
    }

    /**
     * Сравнить одну связку с данными площадки.
     *
     * @param array<string, mixed> $map
     * @param array{stocks:array<string,int>,prices:array<string,float>}|null $remote
     * @return array{stock:?int, price:?float, status:string}
     */
    private function evaluateMapping(array $map, ?MarketplaceClientInterface $client, ?array $remote): array
    {
        $stockKey   = (string) $map['marketplace_sku'];
        $priceKey   = $this->priceIdFor($map);
        $localStock = (int) $map['current_stock'];
        $localPrice = (float) $map['retail_price'];

        $hasStock = $remote !== null && array_key_exists($stockKey, $remote['stocks']);
        $hasPrice = $remote !== null && array_key_exists($priceKey, $remote['prices']);

        if (!$hasStock && !$hasPrice) {
            return ['stock' => null, 'price' => null, 'status' => 'error'];
        }

        $remoteStock = $hasStock ? $remote['stocks'][$stockKey] : null;
        $remotePrice = $hasPrice ? $remote['prices'][$priceKey] : null;

        $stockMatches = $remoteStock === null || $remoteStock === $localStock;
        $priceMatches = $remotePrice === null
            || abs($remotePrice - $localPrice) < self::PRICE_EPSILON;

        if ($stockMatches && $priceMatches) {
            return ['stock' => $remoteStock, 'price' => $remotePrice, 'status' => 'synced'];
        }

        if ($this->autoPush && $client !== null) {
            $this->pushLocalValues($client, $stockKey, $priceKey, $localStock, $localPrice, $stockMatches, $priceMatches);
            return ['stock' => $localStock, 'price' => $localPrice, 'status' => 'synced'];
        }

        return ['stock' => $remoteStock, 'price' => $remotePrice, 'status' => 'mismatch'];
    }

    private function pushLocalValues(
        MarketplaceClientInterface $client,
        string $stockKey,
        string $priceKey,
        int $localStock,
        float $localPrice,
        bool $stockMatches,
        bool $priceMatches
    ): void {
        try {
            if (!$stockMatches) {
                $client->updateStock($stockKey, $localStock);
            }
            if (!$priceMatches) {
                $client->updatePrice($priceKey, $localPrice);
            }
        } catch (Throwable) {
            // Ошибку пуша поглощаем — на следующем прогоне расхождение снова всплывёт.
        }
    }

    /**
     * @param array{stock:?int, price:?float, status:string} $result
     */
    private function persistMapping(int $mappingId, array $result): void
    {
        $stmt = $this->pdo->prepare(
            'UPDATE product_mappings
                SET sync_status = :status,
                    last_remote_stock = :stock,
                    last_remote_price = :price,
                    last_sync_at = NOW()
              WHERE id = :id'
        );

        $stmt->bindValue(':status', $result['status']);
        $stmt->bindValue(':stock', $result['stock'], $result['stock'] === null ? PDO::PARAM_NULL : PDO::PARAM_INT);
        $stmt->bindValue(':price', $result['price']);
        $stmt->bindValue(':id', $mappingId, PDO::PARAM_INT);
        $stmt->execute();
    }

    /** Записать факт прогона в журнал sync_runs. */
    private function recordRun(array $summary, string $source): void
    {
        try {
            $stmt = $this->pdo->prepare(
                'INSERT INTO sync_runs (source, total, synced, mismatch, error, demo_mode, auto_push)
                 VALUES (:source, :total, :synced, :mismatch, :error, :demo, :push)'
            );
            $stmt->bindValue(':source', $source === 'cron' ? 'cron' : 'web');
            $stmt->bindValue(':total', (int) $summary['total'], PDO::PARAM_INT);
            $stmt->bindValue(':synced', (int) $summary['synced'], PDO::PARAM_INT);
            $stmt->bindValue(':mismatch', (int) $summary['mismatch'], PDO::PARAM_INT);
            $stmt->bindValue(':error', (int) $summary['error'], PDO::PARAM_INT);
            $stmt->bindValue(':demo', !empty($summary['demo_mode']) ? 1 : 0, PDO::PARAM_INT);
            $stmt->bindValue(':push', !empty($summary['auto_push']) ? 1 : 0, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Throwable) {
            // Журнал не критичен для результата синхронизации.
        }
    }

    /**
     * @param array<string, mixed> $map
     * @return array<string, mixed>
     */
    private function newRow(array $map): array
    {
        return [
            'product_id'  => (int) $map['product_id'],
            'name'        => (string) $map['name'],
            'sku'         => (string) $map['sku'],
            'local_stock' => (int) $map['current_stock'],
            'local_price' => (float) $map['retail_price'],
            'wb_stock'    => null, 'wb_price'   => null, 'wb_status'   => 'n/a',
            'ozon_stock'  => null, 'ozon_price' => null, 'ozon_status' => 'n/a',
            'status'      => 'pending',
        ];
    }

    /** Идентификатор для запроса цены: nm_id (WB) или marketplace_sku (Ozon). */
    private function priceIdFor(array $map): string
    {
        $nmId = isset($map['nm_id']) ? (string) $map['nm_id'] : '';
        return $nmId !== '' ? $nmId : (string) $map['marketplace_sku'];
    }

    /**
     * @param array<int, array<string, mixed>> $mappings
     * @return array<int, string>
     */
    private function collectStockIds(array $mappings, string $type): array
    {
        $ids = [];
        foreach ($mappings as $map) {
            if ((string) $map['marketplace_type'] === $type) {
                $ids[] = (string) $map['marketplace_sku'];
            }
        }
        return array_values(array_unique($ids));
    }

    /**
     * @param array<int, array<string, mixed>> $mappings
     * @return array<int, string>
     */
    private function collectPriceIds(array $mappings, string $type): array
    {
        $ids = [];
        foreach ($mappings as $map) {
            if ((string) $map['marketplace_type'] === $type) {
                $ids[] = $this->priceIdFor($map);
            }
        }
        return array_values(array_unique($ids));
    }

    /**
     * Итоговый статус: error > mismatch > synced > pending > n/a.
     *
     * @param array<int, string> $statuses
     */
    private function overallStatus(array $statuses): string
    {
        $priority = ['error' => 4, 'mismatch' => 3, 'synced' => 2, 'pending' => 1, 'n/a' => 0];
        $worst = 'pending';
        $worstWeight = $priority['pending'];

        foreach ($statuses as $status) {
            $weight = $priority[$status] ?? 0;
            if ($weight > $worstWeight) {
                $worst = $status;
                $worstWeight = $weight;
            }
        }

        return $worst === 'n/a' ? 'pending' : $worst;
    }

    /**
     * @return array<string, MarketplaceClientInterface> ключ — тип площадки
     */
    private function buildClients(): array
    {
        $connections = (new ConnectionRepository($this->pdo))->active();

        $clients = [];
        foreach ($connections as $conn) {
            $clients[(string) $conn['marketplace_type']] = $this->factory->make($conn);
        }

        return $clients;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function loadMappings(): array
    {
        $stmt = $this->pdo->query(
            'SELECT m.id, m.product_id, m.marketplace_type, m.marketplace_sku, m.nm_id,
                    p.sku, p.name, p.current_stock, p.retail_price
               FROM product_mappings m
               INNER JOIN products p ON p.id = m.product_id
              ORDER BY p.id, m.marketplace_type'
        );

        return $stmt->fetchAll();
    }

    /**
     * @param array<int, array<string, mixed>> $rows
     * @param array<string, string>            $remoteErrors
     * @return array<string, mixed>
     */
    private function buildSummary(array $rows, array $remoteErrors): array
    {
        $counts = ['synced' => 0, 'mismatch' => 0, 'error' => 0, 'pending' => 0];
        foreach ($rows as $row) {
            $status = (string) $row['status'];
            $counts[$status] = ($counts[$status] ?? 0) + 1;
        }

        return [
            'total'        => count($rows),
            'synced'       => $counts['synced'],
            'mismatch'     => $counts['mismatch'],
            'error'        => $counts['error'],
            'demo_mode'    => Env::bool('APP_DEMO_MODE', true),
            'auto_push'    => $this->autoPush,
            'api_errors'   => $remoteErrors,
            'generated_at' => date('c'),
        ];
    }
}
