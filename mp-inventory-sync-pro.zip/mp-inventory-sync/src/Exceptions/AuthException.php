<?php
declare(strict_types=1);

namespace App\Exceptions;

/**
 * Ошибка авторизации на маркетплейсе (HTTP 401/403).
 * Как правило означает протухший или неверный токен/ключ.
 */
final class AuthException extends ApiException
{
}
