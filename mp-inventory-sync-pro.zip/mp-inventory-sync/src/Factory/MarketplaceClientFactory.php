<?php
declare(strict_types=1);

namespace App\Factory;

use App\Clients\MockClient;
use App\Clients\OzonClient;
use App\Clients\WildberriesClient;
use App\Contracts\MarketplaceClientInterface;
use App\Support\Env;
use InvalidArgumentException;

/**
 * Создаёт клиента маркетплейса по строке из marketplace_connections.
 *
 * Если включён демо-режим (APP_DEMO_MODE=true) или ключ выглядит как
 * заглушка/пустой, возвращается MockClient — это даёт безопасный запуск
 * без реальных учётных данных.
 */
final class MarketplaceClientFactory
{
    /**
     * @param array<string, mixed> $connection Строка из marketplace_connections
     */
    public function make(array $connection): MarketplaceClientInterface
    {
        $type        = (string) $connection['marketplace_type'];
        $apiKey      = (string) ($connection['api_key'] ?? '');
        $clientId    = (string) ($connection['client_id'] ?? '');
        $warehouseId = (string) ($connection['warehouse_id'] ?? '');

        if ($this->shouldUseMock($apiKey)) {
            return new MockClient($type);
        }

        return match ($type) {
            'wb'   => new WildberriesClient($apiKey, $warehouseId),
            'ozon' => new OzonClient($clientId, $apiKey, $warehouseId),
            default => throw new InvalidArgumentException("Неизвестный тип маркетплейса: {$type}"),
        };
    }

    private function shouldUseMock(string $apiKey): bool
    {
        if (Env::bool('APP_DEMO_MODE', true)) {
            return true;
        }

        // Подстраховка: явные заглушки не должны уходить в реальный API.
        return $apiKey === ''
            || str_contains(strtolower($apiKey), 'demo')
            || str_contains($apiKey, 'placeholder');
    }
}
