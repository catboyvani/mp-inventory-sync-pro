<?php
declare(strict_types=1);

/**
 * bootstrap.php
 * Единая точка инициализации: автозагрузчик классов (PSR-4 для App\)
 * и загрузка переменных окружения из .env. Сторонние зависимости не требуются.
 */

// --- Автозагрузчик: App\Foo\Bar -> src/Foo/Bar.php ------------------------
spl_autoload_register(static function (string $class): void {
    $prefix  = 'App\\';
    $baseDir = __DIR__ . '/src/';

    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $file     = $baseDir . str_replace('\\', '/', $relative) . '.php';

    if (is_file($file)) {
        require $file;
    }
});

// --- Загрузка .env --------------------------------------------------------
\App\Support\Env::load(__DIR__ . '/.env');
