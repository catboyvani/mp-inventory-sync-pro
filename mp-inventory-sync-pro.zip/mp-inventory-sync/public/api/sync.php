<?php
declare(strict_types=1);

/**
 * api/sync.php — REST-эндпоинт синхронизации.
 *
 * Принимает POST, запускает InventorySyncService и отдаёт чистый JSON.
 * Чувствительные данные (API-ключи) наружу не выводятся в принципе.
 */

use App\Database\Database;
use App\Factory\MarketplaceClientFactory;
use App\Services\InventorySyncService;
use App\Support\Auth;
use App\Support\Security;

require __DIR__ . '/../../bootstrap.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

/**
 * Единый формат JSON-ответа.
 *
 * @param array<string, mixed> $payload
 */
function respond(bool $ok, array $payload, int $httpCode = 200): never
{
    http_response_code($httpCode);
    echo json_encode(
        ['ok' => $ok] + $payload,
        JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
    );
    exit;
}

// --- Авторизация (только для вошедшего администратора) ---------------------
Auth::requireApi();

// --- Валидация метода ------------------------------------------------------
$method = Security::enum($_SERVER['REQUEST_METHOD'] ?? '', ['GET', 'POST'], 'GET');
if ($method !== 'POST') {
    respond(false, ['error' => 'Метод не поддерживается. Используйте POST.'], 405);
}

// --- Защита от CSRF --------------------------------------------------------
$csrf = $_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null);
if (!Auth::csrfValid(is_string($csrf) ? $csrf : null)) {
    respond(false, ['error' => 'Недействительный CSRF-токен. Обновите страницу.'], 419);
}

// --- Пример строгой фильтрации входящего параметра -------------------------
// Необязательный фильтр по площадке: ?type=wb|ozon (демонстрация валидации).
$typeFilter = Security::enum($_POST['type'] ?? null, ['wb', 'ozon'], null);

// --- Запуск синхронизации --------------------------------------------------
try {
    $service = new InventorySyncService(
        Database::connection(),
        new MarketplaceClientFactory()
    );

    $result = $service->run();

    // (Фильтр по площадке здесь оставлен как точка расширения; в учебном
    //  прогоне синхронизируются все активные подключения.)
    unset($typeFilter);

    respond(true, [
        'data'    => $result['rows'],
        'summary' => $result['summary'],
    ]);
} catch (Throwable $e) {
    // Наружу — обобщённое сообщение, детали пишем в лог сервера.
    error_log('[sync] ' . $e->getMessage());
    respond(false, ['error' => 'Внутренняя ошибка синхронизации. Подробности в логах сервера.'], 500);
}
