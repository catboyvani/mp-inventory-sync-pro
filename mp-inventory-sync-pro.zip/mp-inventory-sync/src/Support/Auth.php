<?php
declare(strict_types=1);

namespace App\Support;

/**
 * Минимальная сессионная аутентификация для одного администратора.
 *
 * Учётные данные хранятся в .env:
 *   AUTH_USER           — логин;
 *   AUTH_PASSWORD_HASH  — bcrypt-хеш пароля (НЕ сам пароль).
 *
 * Хеш генерируется командой:  php bin/console.php user:password
 *
 * Также предоставляет CSRF-токен для защиты POST-запросов
 * (дашборд -> api/sync.php, сохранение настроек).
 */
final class Auth
{
    private const SESSION_KEY = 'mp_auth_user';
    private const CSRF_KEY     = 'mp_csrf';

    /** Гарантированно стартовать сессию (один раз). */
    public static function startSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        // В CLI или если вывод уже начался — настоящую сессию не стартуем
        // (используется суперглобал $_SESSION в рамках процесса). В обычном
        // веб-запросе Auth вызывается до вывода, поэтому сессия стартует штатно.
        if (PHP_SAPI === 'cli' || headers_sent()) {
            if (!isset($_SESSION)) {
                $_SESSION = [];
            }
            return;
        }

        session_set_cookie_params([
            'httponly' => true,
            'samesite' => 'Lax',
            // 'secure' => true  // включить при работе по HTTPS
        ]);
        session_start();
    }

    /** Проверить логин/пароль и при успехе авторизовать. */
    public static function attempt(string $user, string $password): bool
    {
        $expectedUser = (string) Env::get('AUTH_USER', '');
        $hash         = (string) Env::get('AUTH_PASSWORD_HASH', '');

        if ($expectedUser === '' || $hash === '') {
            return false;
        }

        $userOk = hash_equals($expectedUser, $user);
        $passOk = password_verify($password, $hash);

        // Сравниваем оба фактора всегда (без раннего выхода) — постоянное время.
        if ($userOk && $passOk) {
            self::startSession();
            session_regenerate_id(true);
            $_SESSION[self::SESSION_KEY] = $user;
            return true;
        }

        return false;
    }

    public static function check(): bool
    {
        self::startSession();
        return !empty($_SESSION[self::SESSION_KEY]);
    }

    public static function user(): ?string
    {
        self::startSession();
        return $_SESSION[self::SESSION_KEY] ?? null;
    }

    public static function logout(): void
    {
        self::startSession();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    /** Веб-страница: если не авторизован — редирект на login.php. */
    public static function requireWeb(): void
    {
        if (!self::check()) {
            header('Location: login.php');
            exit;
        }
    }

    /** API: если не авторизован — 401 JSON и выход. */
    public static function requireApi(): void
    {
        if (!self::check()) {
            http_response_code(401);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => 'Требуется авторизация.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    // --- CSRF -----------------------------------------------------------

    public static function csrfToken(): string
    {
        self::startSession();
        if (empty($_SESSION[self::CSRF_KEY])) {
            $_SESSION[self::CSRF_KEY] = bin2hex(random_bytes(32));
        }
        return $_SESSION[self::CSRF_KEY];
    }

    public static function csrfValid(?string $token): bool
    {
        self::startSession();
        $expected = $_SESSION[self::CSRF_KEY] ?? '';
        return $expected !== '' && is_string($token) && hash_equals($expected, $token);
    }
}
